/*
 * display_draw.c
 *
 * Created: 19.12.2025 13:53:24
 *  Author: david
 */ 
#include <avr/io.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include "font/FontData.h"
#include "display_draw.h"
#include "display.h"

static uint8_t **_video_buffer;
static uint8_t _display_width = 0;
static uint8_t _display_height = 0;
static uint8_t _display_x_pos = 0;
static uint8_t _display_y_pos = 0;
static uint8_t _display_pages = 0;
static uint8_t _display_base_page = 0;
static uint8_t _display_shift = 0;
static bool _display_initialized = false;

void display_draw_init(uint8_t display_width, uint8_t display_height, uint8_t display_x_pos, uint8_t display_y_pos)
{
	display_init();
	_display_initialized = false;
	if (display_width <= OLED_PIXEL_X && display_height <= OLED_PIXEL_Y)
	{
		_display_width = display_width;
		_display_height = display_height;
		_display_pages = (_display_height + 7) / 8;
		_display_base_page = display_y_pos >> 3;
		_display_x_pos = display_x_pos;
		_display_y_pos = display_y_pos;
		_display_shift = display_y_pos % 8;
		
		_video_buffer = malloc(_display_pages*sizeof(uint8_t *));
		for(uint8_t i = 0; i < _display_pages; i++)
		{
			_video_buffer[i] = malloc(_display_width*sizeof(uint8_t));
			if (!_video_buffer[i])
			{
				display_string_pos_P(0, 0, PSTR("draw_init failed!"));
				display_string_pos_P(0, 1, PSTR("Not enough SRAM!"));
				exit(-1);
			}
			memset(_video_buffer[i], 0, _display_width);
		}
		_display_initialized = true;
	}
	else
	{
		display_string_pos_P(0, 0, PSTR("draw_init failed!"));
		display_string_pos_P(0, 1, PSTR("Display too big!"));
		exit(-1);
	}
	
}

void display_draw_clear()
{
	if (_display_initialized)
	{
		display_clear();
		for(uint8_t i = 0; i < _display_pages; i++)
			memset(_video_buffer[i], 0, _display_width);
	}
}

static void _display_draw_column(uint8_t x_video_buffer, uint8_t x_display, uint8_t y_display, uint8_t video_buffer_page, uint8_t display_page)
{
	uint8_t byte_to_draw = _video_buffer[video_buffer_page][x_video_buffer];
	if (_display_shift == 0)
	{
		display_pixel_byte(x_display, y_display, byte_to_draw);
	}
	else
	{
		uint8_t upper_from_video = 0x00;
		uint8_t lower_from_video = 0x00;
		if (video_buffer_page > 0)
		upper_from_video = _video_buffer[video_buffer_page - 1][x_video_buffer] >> (8 - _display_shift);
		if (video_buffer_page + 1 < _display_pages)
		lower_from_video = _video_buffer[video_buffer_page + 1][x_video_buffer] << _display_shift;
		
		uint8_t upper = byte_to_draw << _display_shift | upper_from_video;
		uint8_t lower = byte_to_draw >> (8 - _display_shift) | lower_from_video;
		
		display_pixel_byte(x_display, display_page << 3, upper);
		
		if (display_page + 1 < OLED_PAGES)
			display_pixel_byte(x_display, (display_page + 1) << 3, lower);
	}
}

static void _display_draw_clear_pixel(uint8_t x, uint8_t y, bool clear)
{
	if (x >= _display_width || y >= _display_height) return;
	uint8_t x_abs = x + _display_x_pos;
	uint8_t y_abs = y + _display_y_pos;
	if (x_abs >= OLED_PIXEL_X || y_abs >= OLED_PIXEL_Y) return;
	uint8_t video_buffer_page = y >> 3;
	uint8_t display_page = _display_base_page + video_buffer_page;

	uint8_t bit = (1 << (uint8_t)(y % 8));
	
	
	if (clear == false)
	{
		// check if bit is already set and therefore drawn
		if ((_video_buffer[video_buffer_page][x] & bit) == bit) return; // pixel already set
		_video_buffer[video_buffer_page][x] |= bit;
	}
	else
	{
		// check if pixel is already cleared
		if (!((_video_buffer[video_buffer_page][x] & bit) == bit)) return; // pixel already cleared
		_video_buffer[video_buffer_page][x] &= ~bit;
	}
	_display_draw_column(x, x_abs, y_abs, video_buffer_page, display_page);
	
}

static void _display_draw_clear_byte(uint8_t x, uint8_t y, uint8_t byte, bool clear)
{
	if (x >= _display_width || y >= _display_height) return;
	uint8_t x_abs = x + _display_x_pos;
	uint8_t y_abs = y + _display_y_pos;
	if (x_abs >= OLED_PIXEL_X || y_abs >= OLED_PIXEL_Y) return;

	uint8_t shift = y & 7;
	uint8_t video_buffer_page = y >> 3;
	uint8_t display_page = _display_base_page + video_buffer_page;

	if (shift == 0)
	{
		if (clear == false)
		{
			if (_video_buffer[video_buffer_page][x] == byte) return;
			_video_buffer[video_buffer_page][x] |= byte;
		}
		else
		{
			if (!(_video_buffer[video_buffer_page][x] & byte)) return;
			_video_buffer[video_buffer_page][x] &= ~byte;
		}
		_display_draw_column(x, x_abs, y_abs, video_buffer_page, display_page);
	}
	else
	{
		// Byte spans two pages — split and write each half separately
		uint8_t upper_bits = byte << shift;
		uint8_t lower_bits = byte >> (8 - shift);

		uint8_t old_u = _video_buffer[video_buffer_page][x];
		uint8_t new_u = clear ? (old_u & ~upper_bits) : (old_u | upper_bits);
		if (new_u != old_u)
		{
			_video_buffer[video_buffer_page][x] = new_u;
			uint8_t y_abs_u = (uint8_t)(video_buffer_page * 8u + _display_y_pos);
			_display_draw_column(x, x_abs, y_abs_u, video_buffer_page, display_page);
		}

		if (lower_bits && video_buffer_page + 1 < _display_pages)
		{
			uint8_t old_l = _video_buffer[video_buffer_page + 1][x];
			uint8_t new_l = clear ? (old_l & ~lower_bits) : (old_l | lower_bits);
			if (new_l != old_l)
			{
				_video_buffer[video_buffer_page + 1][x] = new_l;
				uint8_t y_abs_l = (uint8_t)((video_buffer_page + 1) * 8u + _display_y_pos);
				_display_draw_column(x, x_abs, y_abs_l, video_buffer_page + 1, display_page + 1);
			}
		}
	}
}

static void _display_draw_clear_hline(uint8_t x, uint8_t y, uint8_t width, bool clear)
{
	if (width == 0) return;
	if (y >= _display_height) return;
	if (x >= _display_width) return;

	// clip width
	if ((uint16_t)x + width > _display_width)
		width = (uint8_t)(_display_width - x);

	uint8_t page = y >> 3;
	uint8_t bit  = (1 << (y & 7));
	uint8_t display_page = (uint8_t)(_display_base_page + page);

	for (uint8_t i = 0; i < width; i++)
	{
		uint8_t xi = x + i;

		uint8_t oldv = _video_buffer[page][xi];
		uint8_t newv = clear ? (uint8_t)(oldv & (uint8_t)~bit) : (uint8_t)(oldv | bit);

		if (newv == oldv) continue;

		_video_buffer[page][xi] = newv;

		uint8_t x_abs = (uint8_t)(xi + _display_x_pos);
		uint8_t y_abs = (uint8_t)(y  + _display_y_pos);

		// Bounds (wie in deinen anderen Funktionen)
		if (x_abs >= OLED_PIXEL_X || y_abs >= OLED_PIXEL_Y) continue;

		// Flush nur diese Spalte
		_display_draw_column(xi, x_abs, y_abs, page, display_page);
	}
}

static void _display_draw_clear_vline(uint8_t x, uint8_t y, uint8_t height, bool clear)
{
	if (height == 0) return;
	for (uint8_t i = 0; i < height; i++)
	{
		if (clear) display_clear_pixel(x, (uint8_t)(y + i));
		else       display_draw_pixel(x, (uint8_t)(y + i));
	}
}

void display_draw_pixel(uint8_t x, uint8_t y)
{
	_display_draw_clear_pixel(x, y, false);
}

void display_clear_pixel(uint8_t x, uint8_t y)
{
	_display_draw_clear_pixel(x, y, true);
}

void display_draw_byte(uint8_t x, uint8_t y, uint8_t byte)
{
	_display_draw_clear_byte(x, y, byte, false);
}

void display_clear_byte(uint8_t x, uint8_t y, uint8_t byte)
{
	_display_draw_clear_byte(x, y, byte, true);
}

// Bresenham-Algorithmus
static void _display_draw_clear_line_step(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, bool clear, uint8_t step)
{
	if (step == 0) step = 1;

	x1 = (x1 < _display_width)  ? x1 : _display_width  - 1;
	x2 = (x2 < _display_width)  ? x2 : _display_width  - 1;
	y1 = (y1 < _display_height) ? y1 : _display_height - 1;
	y2 = (y2 < _display_height) ? y2 : _display_height - 1;

	int16_t dx = abs((int16_t)x2 - (int16_t)x1);
	int16_t dy = abs((int16_t)y2 - (int16_t)y1);
	int8_t sx  = (x1 < x2) ? 1 : -1;
	int8_t sy  = (y1 < y2) ? 1 : -1;
	int16_t err = dx - dy;

	uint8_t ctr = 0;

	while (1)
	{
		if ((ctr % step) == 0)
		{
			if (clear) display_clear_pixel(x1, y1);
			else       display_draw_pixel(x1, y1);
		}
		ctr++;

		if (x1 == x2 && y1 == y2) break;

		int16_t e2 = err << 1;
		if (e2 > -dy) { err -= dy; x1 = (uint8_t)(x1 + sx); }
		if (e2 <  dx) { err += dx; y1 = (uint8_t)(y1 + sy); }
	}
}

void display_draw_line(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	_display_draw_clear_line_step(x1, y1, x2, y2, false, 1);
}

void display_clear_line(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	_display_draw_clear_line_step(x1, y1, x2, y2, true, 1);
}

void display_draw_line_with_step(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t step)
{
	_display_draw_clear_line_step(x1, y1, x2, y2, false, step);
}

void display_clear_line_with_step(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t step)
{
	_display_draw_clear_line_step(x1, y1, x2, y2, true, step);
}


static void _display_draw_clear_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, bool clear)
{
	if (w == 0 || h == 0) return;

	// Top / Bottom
	_display_draw_clear_hline(x, y, w, clear);
	if (h > 1)
		_display_draw_clear_hline(x, (uint8_t)(y + h - 1), w, clear);

	// Left / Right
	if (h > 2)
	{
		_display_draw_clear_vline(x, (uint8_t)(y + 1), (uint8_t)(h - 2), clear);
		if (w > 1)
		_display_draw_clear_vline((uint8_t)(x + w - 1), (uint8_t)(y + 1), (uint8_t)(h - 2), clear);
	}
}

static void _display_draw_clear_fill_rect(uint8_t x, uint8_t y, uint8_t w, uint8_t h, bool clear)
{
	if (w == 0 || h == 0) return;

	for (uint8_t yy = 0; yy < h; yy++)
		_display_draw_clear_hline(x, (uint8_t)(y + yy), w, clear);
}

void display_draw_rect(uint8_t x, uint8_t y, uint8_t width, uint8_t height, bool filled)
{
	if (filled) _display_draw_clear_fill_rect(x, y, height, width, false);
	else _display_draw_clear_rect(x, y, width, height, false);
}

void display_clear_rect(uint8_t x, uint8_t y, uint8_t width, uint8_t height, bool filled)
{
	if (filled) _display_draw_clear_fill_rect(x, y, height, width, true);
	else _display_draw_clear_rect(x, y, width, height, true);
}

static void _display_draw_overwrite_byte_masked(uint8_t x, uint8_t y, uint8_t byte, uint8_t mask)
{
	if (x >= _display_width || y >= _display_height) return;

	uint8_t x_abs = x + _display_x_pos;
	uint8_t y_abs = y + _display_y_pos;
	if (x_abs >= OLED_PIXEL_X || y_abs >= OLED_PIXEL_Y) return;

	uint8_t shift = y & 7;
	uint8_t video_buffer_page = y >> 3;
	uint8_t display_page = _display_base_page + video_buffer_page;

	if (shift == 0)
	{
		uint8_t oldv = _video_buffer[video_buffer_page][x];
		uint8_t newv = (uint8_t)((oldv & (uint8_t)~mask) | (byte & mask));
		if (newv == oldv) return;
		_video_buffer[video_buffer_page][x] = newv;
		_display_draw_column(x, x_abs, y_abs, video_buffer_page, display_page);
	}
	else
	{
		// Byte spans two pages — split and write each half separately
		uint8_t upper_byte = byte << shift;
		uint8_t upper_mask = mask << shift;
		uint8_t lower_byte = byte >> (8 - shift);
		uint8_t lower_mask = mask >> (8 - shift);

		uint8_t old_u = _video_buffer[video_buffer_page][x];
		uint8_t new_u = (uint8_t)((old_u & ~upper_mask) | (upper_byte & upper_mask));
		if (new_u != old_u)
		{
			_video_buffer[video_buffer_page][x] = new_u;
			uint8_t y_abs_u = (uint8_t)(video_buffer_page * 8u + _display_y_pos);
			_display_draw_column(x, x_abs, y_abs_u, video_buffer_page, display_page);
		}

		if (lower_mask && video_buffer_page + 1 < _display_pages)
		{
			uint8_t old_l = _video_buffer[video_buffer_page + 1][x];
			uint8_t new_l = (uint8_t)((old_l & ~lower_mask) | (lower_byte & lower_mask));
			if (new_l != old_l)
			{
				_video_buffer[video_buffer_page + 1][x] = new_l;
				uint8_t y_abs_l = (uint8_t)((video_buffer_page + 1) * 8u + _display_y_pos);
				_display_draw_column(x, x_abs, y_abs_l, video_buffer_page + 1, display_page + 1);
			}
		}
	}
}

static void _display_draw_clear_bitmap(uint8_t x, uint8_t y, const void *bitmap, uint8_t width, uint8_t height,
bool clear, bool from_progmem, bool horizontal, bool transparent)
{
	if (!bitmap) return;
	if (width == 0 || height == 0) return;

	// clip start
	if (x >= _display_width || y >= _display_height) return;

	// clip width/height to drawing area
	if ((uint16_t)x + width > _display_width)
	width = (uint8_t)(_display_width - x);

	uint8_t eff_h = height;
	if ((uint16_t)y + eff_h > _display_height)
	eff_h = (uint8_t)(_display_height - y);

	if (width == 0 || eff_h == 0) return;

	const uint8_t pages = (uint8_t)((eff_h + 7) >> 3);
	const uint8_t last_rem  = (uint8_t)(eff_h & 7);
	const uint8_t last_mask = (last_rem == 0) ? 0xFFu : (uint8_t)((1u << last_rem) - 1u);

	// NOTE:
	// - clear==true  -> l�scht Bits (wie bisher)
	// - clear==false && transparent==true  -> "transparent draw" (nur 1en setzen, OR)
	// - clear==false && transparent==false -> "overwrite draw" (masked replace)

	if (!horizontal)
	{
		for (uint8_t page = 0; page < pages; page++)
		{
			uint8_t mask = (page == (uint8_t)(pages - 1)) ? last_mask : 0xFFu;

			for (uint8_t col = 0; col < width; col++)
			{
				const uint16_t idx = (uint16_t)page * width + col;
				uint8_t out = from_progmem
				? pgm_read_byte((const uint8_t*)bitmap + idx)
				: *((const uint8_t*)bitmap + idx);

				const uint8_t xx = (uint8_t)(x + col);
				const uint8_t yy = (uint8_t)(y + (page << 3));

				if (clear)
				{
					// nur g�ltige Bits l�schen
					_display_draw_clear_byte(xx, yy, (uint8_t)(out & mask), true);
				}
				else if (transparent)
				{
					// nur g�ltige Bits setzen
					_display_draw_clear_byte(xx, yy, (uint8_t)(out & mask), false);
				}
				else
				{
					// overwrite, aber nur g�ltige Bits ersetzen
					_display_draw_overwrite_byte_masked(xx, yy, out, mask);
				}
			}
		}
		return;
	}

	// horizontal layout
	const uint8_t bytes_per_row = (uint8_t)((width + 7) >> 3);

	for (uint8_t col = 0; col < width; col++)
	{
		const uint8_t byte_in_row = (uint8_t)(col >> 3);
		const uint8_t mask_src = (uint8_t)(0x80u >> (col & 7));

		for (uint8_t page = 0; page < pages; page++)
		{
			uint8_t out = 0;

			for (uint8_t bit = 0; bit < 8; bit++)
			{
				const uint8_t row = (uint8_t)(page * 8u + bit);
				if (row >= eff_h) break;

				const uint16_t idx = (uint16_t)row * bytes_per_row + byte_in_row;

				uint8_t v = from_progmem
				? pgm_read_byte((const uint8_t*)bitmap + idx)
				: *((const uint8_t*)bitmap + idx);

				if (v & mask_src) out |= (uint8_t)(1u << bit);
			}

			uint8_t mask = (page == (uint8_t)(pages - 1)) ? last_mask : 0xFFu;

			const uint8_t xx = (uint8_t)(x + col);
			const uint8_t yy = (uint8_t)(y + (page << 3));

			if (clear)
			{
				_display_draw_clear_byte(xx, yy, (uint8_t)(out & mask), true);
			}
			else if (transparent)
			{
				_display_draw_clear_byte(xx, yy, (uint8_t)(out & mask), false);
			}
			else
			{
				_display_draw_overwrite_byte_masked(xx, yy, out, mask);
			}
		}
	}
}

void display_draw_bitmap_transparent(uint8_t x, uint8_t y, const void *bitmap, uint8_t width, uint8_t height, bool horizontal)
{
	_display_draw_clear_bitmap(x, y, bitmap, width, height, false, false, horizontal, true);
}

void display_draw_bitmap_transparent_P(uint8_t x, uint8_t y, PGM_P bitmap, uint8_t width, uint8_t height, bool horizontal)
{
	_display_draw_clear_bitmap(x, y, (const void *)bitmap, width, height, false, true, horizontal, true);
}

void display_draw_bitmap(uint8_t x, uint8_t y, const void *bitmap, uint8_t width, uint8_t height, bool horizontal)
{
	_display_draw_clear_bitmap(x, y, bitmap, width, height, false, false, horizontal, false);
}

void display_draw_bitmap_P(uint8_t x, uint8_t y, PGM_P bitmap, uint8_t width, uint8_t height, bool horizontal)
{
	_display_draw_clear_bitmap(x, y, (const void *)bitmap, width, height, false, true, horizontal, false);
}

// clear bleibt clear (transparent-flag egal)
void display_clear_bitmap(uint8_t x, uint8_t y, const void *bitmap, uint8_t width, uint8_t height, bool horizontal)
{
	_display_draw_clear_bitmap(x, y, bitmap, width, height, true, false, horizontal, true);
}

void display_clear_bitmap_P(uint8_t x, uint8_t y, PGM_P bitmap, uint8_t width, uint8_t height, bool horizontal)
{
	_display_draw_clear_bitmap(x, y, (const void *)bitmap, width, height, true, true, horizontal, true);
}

static inline const uint8_t* _font_glyph_ptr(char c)
{
	if ((uint8_t)c < fontParam.char_first || (uint8_t)c > fontParam.char_last)
	c = '?';

	uint8_t idx = (uint8_t)c - fontParam.char_first;
	// Bei 5x8 / 7x8 gilt: bytes_per_char == fontParam.width
	return &fontData[(uint16_t)idx * fontParam.width];
}


void display_draw_char(uint8_t x, uint8_t y, char c, FontSize_t size, bool clear_bg)
{
	uint16_t scale_q = (uint16_t)size;   // direkt Q8.8 Wert

	if (scale_q == 0)
		scale_q = FONT_SIZE_1X;

	const uint8_t* g = _font_glyph_ptr(c);
	uint8_t src_w = fontParam.width;
	uint8_t src_h = fontParam.height;

	uint16_t dst_w = ((uint16_t)src_w * scale_q + 128) >> 8;
	uint16_t dst_h = ((uint16_t)src_h * scale_q + 128) >> 8;

	if (clear_bg)
	display_clear_rect(x, y, (uint8_t)dst_w, (uint8_t)dst_h, true);

	for (uint16_t dy = 0; dy < dst_h; dy++)
	{
		uint8_t sy = (uint8_t)(((uint32_t)dy << 8) / scale_q);
		if (sy >= src_h) sy = src_h - 1;

		for (uint16_t dx = 0; dx < dst_w; dx++)
		{
			uint8_t sx = (uint8_t)(((uint32_t)dx << 8) / scale_q);
			if (sx >= src_w) sx = src_w - 1;

			uint8_t colBits = pgm_read_byte(&g[sx]);
			if (colBits & (1 << sy))
			display_draw_pixel((uint8_t)(x + dx),
			(uint8_t)(y + dy));
		}
	}
}


void _display_draw_string(uint8_t x, uint8_t y, const char* s, FontSize_t size, bool clear_bg, bool from_progmem)
{
	if (!s) return;

	uint16_t scale_q = (uint16_t)size;
	if (scale_q == 0)
	scale_q = FONT_SIZE_1X;

	uint8_t src_w = fontParam.width;
	uint8_t src_h = fontParam.height;

	// skalierte Ma�e
	uint16_t dst_w       = ((uint16_t)src_w * scale_q + 128) >> 8;
	uint16_t dst_h       = ((uint16_t)src_h * scale_q + 128) >> 8;
	uint16_t dst_spacing = ((uint16_t)fontParam.spacing * scale_q + 128) >> 8;

	// advance (pro Zeichen)
	uint16_t adv16 = dst_w + dst_spacing;
	uint8_t adv = (uint8_t)(adv16 > 255 ? 255 : adv16);

	while (1)
	{
		char c = from_progmem ? pgm_read_byte(s++) : *s++;
		if (c == '\0') break;

		// Hintergrund inkl. spacing l�schen (damit keine Reste bleiben)
		if (clear_bg)
		{
			uint16_t bg_w16 = dst_w + dst_spacing;
			uint8_t bg_w = (uint8_t)(bg_w16 > 255 ? 255 : bg_w16);
			uint8_t bg_h = (uint8_t)(dst_h > 255 ? 255 : dst_h);

			display_clear_rect(x, y, bg_w, bg_h, true);
		}

		// Zeichen zeichnen
		display_draw_char(x, y, c, size, false);

		// n�chster Cursor
		x = (uint8_t)(x + adv);
	}
}

void display_draw_string(uint8_t x, uint8_t y, const char* s, FontSize_t size)
{
	_display_draw_string(x, y, s, size, true, false);
}

void display_draw_string_P(uint8_t x, uint8_t y, PGM_P s, FontSize_t size)
{
	_display_draw_string(x, y, s, size, true, true);
}

#ifdef DISPLAY_DRAW_SELFTEST

static bool _taster_down(void)
{
	return (PINA & (1 << PA0)) == 0;   // active low
}

static void _wait_taster_pressed(void)
{
	// warten bis gedr�ckt
	while (!_taster_down()) { _delay_ms(10); }

	// entprellen: muss nach kurzer Zeit noch gedr�ckt sein
	_delay_ms(20);
	if (!_taster_down())
		return _wait_taster_pressed();  // nochmal versuchen (oder while-loop)

	// warten bis losgelassen
	while (_taster_down()) { _delay_ms(10); }

	// entprellen release
	_delay_ms(20);
}

void display_draw_selftest_loop()
{
	DDRA  &= ~(1<<PA0);
	PORTA |=  (1<<PA0);
	display_draw_init(120, 56, 2, 2);

	// wir zeichnen unterhalb der Statuszeile
	const uint8_t y0 = 10; // Abstand nach oben (Font 5x8 + spacing)

	for (;;)
	{
		// -------------------------------------------------
		// 1) Rect Rahmen + Clear
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("1) rect frame"), FONT_SIZE_1X);
		display_draw_rect(0, y0, _display_width, _display_height - y0, false);
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("1) clear rect frame"), FONT_SIZE_1X);
		display_clear_rect(0, y0, _display_width, _display_height - y0, false);
		_wait_taster_pressed();

		// -------------------------------------------------
		// 2) Pixel + Clear
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("2) pixels"), FONT_SIZE_1X);
		display_draw_pixel(0, y0);
		display_draw_pixel((uint8_t)(_display_width - 1), y0);
		display_draw_pixel(0, (uint8_t)(_display_height - 1));
		display_draw_pixel((uint8_t)(_display_width - 1), (uint8_t)(_display_height - 1));

		uint8_t d = (_display_width < (_display_height - y0)) ? _display_width : (uint8_t)(_display_height - y0);
		for (uint8_t i = 0; i < d; i++)
		display_draw_pixel(i, (uint8_t)(y0 + i));
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("2) clear pixels"), FONT_SIZE_1X);
		display_clear_pixel(0, y0);
		display_clear_pixel((uint8_t)(_display_width - 1), y0);
		display_clear_pixel(0, (uint8_t)(_display_height - 1));
		display_clear_pixel((uint8_t)(_display_width - 1), (uint8_t)(_display_height - 1));
		for (uint8_t i = 0; i < d; i++)
		display_clear_pixel(i, (uint8_t)(y0 + i));
		_wait_taster_pressed();

		// -------------------------------------------------
		// 3) Byte-Muster + Clear
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("3) bytes AA/55"), FONT_SIZE_1X);
		for (uint8_t x = 0; x < _display_width; x += 2)
		{
			display_draw_byte(x, y0, 0xAA);
			if ((uint8_t)(x + 1) < _display_width)
			display_draw_byte((uint8_t)(x + 1), y0, 0x55);
		}
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("3) clear bytes"), FONT_SIZE_1X);
		for (uint8_t x = 0; x < _display_width; x += 2)
		{
			display_clear_byte(x, y0, 0xFF);
			if ((uint8_t)(x + 1) < _display_width)
			display_clear_byte((uint8_t)(x + 1), y0, 0xFF);
		}
		_wait_taster_pressed();

		// -------------------------------------------------
		// 4) hline / vline + Clear
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("4) hline/vline"), FONT_SIZE_1X);
		_display_draw_clear_hline(0, y0, _display_width, false);
		_display_draw_clear_hline(0, (uint8_t)(y0 + (_display_height - y0)/2), _display_width, false);
		_display_draw_clear_hline(0, (uint8_t)(_display_height - 1), _display_width, false);

		_display_draw_clear_vline(0, y0, (uint8_t)(_display_height - y0), false);
		_display_draw_clear_vline((uint8_t)(_display_width / 2), y0, (uint8_t)(_display_height - y0), false);
		_display_draw_clear_vline((uint8_t)(_display_width - 1), y0, (uint8_t)(_display_height - y0), false);
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("4) clear hline/vline"), FONT_SIZE_1X);
		_display_draw_clear_hline(0, y0, _display_width, true);
		_display_draw_clear_hline(0, (uint8_t)(y0 + (_display_height - y0)/2), _display_width, true);
		_display_draw_clear_hline(0, (uint8_t)(_display_height - 1), _display_width, true);

		_display_draw_clear_vline(0, y0, (uint8_t)(_display_height - y0), true);
		_display_draw_clear_vline((uint8_t)(_display_width / 2), y0, (uint8_t)(_display_height - y0), true);
		_display_draw_clear_vline((uint8_t)(_display_width - 1), y0, (uint8_t)(_display_height - y0), true);
		_wait_taster_pressed();

		// -------------------------------------------------
		// 5) Linien + Clear
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("5) lines"), FONT_SIZE_1X);
		display_draw_line(0, y0, (uint8_t)(_display_width - 1), (uint8_t)(_display_height - 1));
		display_draw_line(0, (uint8_t)(_display_height - 1), (uint8_t)(_display_width - 1), y0);
		display_draw_line_with_step(0, (uint8_t)(y0 + (_display_height - y0)/2),
		(uint8_t)(_display_width - 1),
		(uint8_t)(y0 + (_display_height - y0)/2), 2);
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("5) clear lines"), FONT_SIZE_1X);
		display_clear_line(0, y0, (uint8_t)(_display_width - 1), (uint8_t)(_display_height - 1));
		display_clear_line(0, (uint8_t)(_display_height - 1), (uint8_t)(_display_width - 1), y0);
		display_clear_line_with_step(0, (uint8_t)(y0 + (_display_height - y0)/2),
		(uint8_t)(_display_width - 1),
		(uint8_t)(y0 + (_display_height - y0)/2), 2);
		_wait_taster_pressed();

		// -------------------------------------------------
		// 6) Rechtecke (frame + filled) + Clear
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("6) rect frame"), FONT_SIZE_1X);
		display_draw_rect(4, y0 + 2, (uint8_t)(_display_width - 8), (uint8_t)(_display_height - y0 - 4), false);
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("6) clear rect frame"), FONT_SIZE_1X);
		display_clear_rect(4, y0 + 2, (uint8_t)(_display_width - 8), (uint8_t)(_display_height - y0 - 4), false);
		_wait_taster_pressed();

		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("6) rect filled"), FONT_SIZE_1X);
		display_draw_rect(10, y0 + 6, (uint8_t)(_display_width - 20), (uint8_t)(_display_height - y0 - 12), true);
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("6) clear rect filled"), FONT_SIZE_1X);
		display_clear_rect(10, y0 + 6, (uint8_t)(_display_width - 20), (uint8_t)(_display_height - y0 - 12), true);
		_wait_taster_pressed();

		// -------------------------------------------------
		// 7) Bitmaps + Clear
		// -------------------------------------------------
		static const uint8_t smiley32x32[] PROGMEM =
		{
			0x00, 0x00, 0x00, 0x00, 0x3f, 0xff, 0xfe, 0x00, 0x40, 0x00, 0x01, 0xe0, 0xb0, 0x00, 0x00, 0x30,
			0x20, 0x00, 0x00, 0x18, 0x60, 0x00, 0x00, 0x08, 0x40, 0x00, 0x00, 0x04, 0x40, 0x00, 0x00, 0x04,
			0x40, 0x00, 0x00, 0x02, 0x41, 0xe0, 0x1f, 0x02, 0x46, 0x20, 0x1c, 0xc2, 0x46, 0x20, 0x10, 0x62,
			0x41, 0xe0, 0x30, 0x22, 0x40, 0x00, 0x1f, 0xe2, 0x40, 0x00, 0x00, 0x04, 0x40, 0x00, 0x00, 0x04,
			0x40, 0x02, 0x00, 0x04, 0x60, 0x02, 0x00, 0x08, 0x20, 0x02, 0x00, 0x08, 0x21, 0x00, 0x00, 0x10,
			0x31, 0x80, 0x01, 0x30, 0x10, 0x80, 0x06, 0x20, 0x0c, 0x60, 0x0c, 0x40, 0x06, 0x1c, 0x30, 0xc0,
			0x03, 0x03, 0xc0, 0x80, 0x01, 0x80, 0x03, 0x00, 0x00, 0x70, 0x1e, 0x00, 0x00, 0x0f, 0xf0, 0x00,
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
		};
		static const uint8_t t_block_16x8[] PROGMEM =
		{
			0b00001111, 0b11111111,
			0b00001001, 0b10011001,
			0b00001001, 0b10011001,
			0b00001111, 0b11111111,
			0b00000000, 0b11110000,
			0b00000000, 0b10010000,
			0b00000000, 0b10010000,
			0b00000000, 0b11110000
		};
		
		static const uint8_t flower_32x32[] PROGMEM = {
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
			0x00, 0x00, 0xf0, 0x00, 0x00, 0x03, 0x9c, 0x00, 0x00, 0x02, 0x06, 0x00, 0x00, 0x06, 0x02, 0x00,
			0x03, 0xfc, 0x02, 0x00, 0x06, 0x06, 0x02, 0x00, 0x04, 0x00, 0x06, 0x00, 0x04, 0x00, 0x04, 0x00,
			0x04, 0x00, 0x0f, 0x00, 0x06, 0x03, 0x81, 0x00, 0x03, 0x03, 0x81, 0x80, 0x01, 0x83, 0x81, 0x00,
			0x03, 0xe0, 0x03, 0x00, 0x04, 0x00, 0x0e, 0x00, 0x04, 0x00, 0x0f, 0x00, 0x04, 0x00, 0x05, 0x00,
			0x06, 0x0c, 0x04, 0x80, 0x03, 0x1c, 0x04, 0xc0, 0x01, 0xb4, 0x04, 0x40, 0x00, 0xe4, 0x04, 0x60,
			0x00, 0x04, 0x08, 0x20, 0x00, 0x03, 0x08, 0x30, 0x00, 0x01, 0xf0, 0x10, 0x00, 0x00, 0x00, 0x10,
			0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x18, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x08
		};
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("7) bitmaps"), FONT_SIZE_1X);

		display_draw_bitmap_P(20, y0, (PGM_P)smiley32x32, 32, 32, true);
		display_draw_bitmap_P(60, y0, (PGM_P)t_block_16x8, 16, 8, true);
		display_draw_bitmap_P(80, 20, (PGM_P)flower_32x32, 32, 32, true);
		_wait_taster_pressed();

		display_draw_string_P(0, 0, PSTR("7) clear bitmaps"), FONT_SIZE_1X);
		display_clear_bitmap_P(20, y0, (PGM_P)smiley32x32, 32, 32, true);
		display_clear_bitmap_P(60, y0, (PGM_P)t_block_16x8, 16, 8, true);
		display_clear_bitmap_P(80, 20, (PGM_P)flower_32x32, 32, 32, true);
		_wait_taster_pressed();

		// -------------------------------------------------
		// 8) Text + Clear (clear_bg test)
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("8) text"), FONT_SIZE_1X);
		display_draw_string_P(0, y0, PSTR("Font 0.75x"), FONT_SIZE_0_75X);
		display_draw_string_P(0, y0 + 6, PSTR("Font 1x"), FONT_SIZE_1X);
		display_draw_string_P(0, y0 + 14, PSTR("1.5x"), FONT_SIZE_1_5X);
		display_draw_string_P(0, y0 + 26, PSTR("2x"), FONT_SIZE_2X);
		_wait_taster_pressed();
		
		// -------------------------------------------------
		// 9) Animationen
		// -------------------------------------------------
		display_draw_clear();
		display_draw_string_P(0, 0, PSTR("9) animations"), FONT_SIZE_1X);
		uint8_t prev = 0;
		while ((PINA & (1<<PA0)) == 1)
		{
			for(uint8_t i = 0; i < lama_bitmap_array_LEN; i++)
			{
				display_clear_bitmap_P(0, y0, (PGM_P)lama_bitmap_array[prev], 48, 48, false);
				display_draw_bitmap_P(0, y0, (PGM_P)lama_bitmap_array[i], 48, 48, false);
				prev = i;
				_delay_ms(80);
			}
		}
	}
}

#endif