/*
 * lama.h
 *
 * Created: 25.02.2026 14:09:28
 *  Author: david
 */ 


#ifndef LAMA_H_
#define LAMA_H_
#include <avr/io.h>
#include <avr/pgmspace.h>
extern const uint8_t lama_bitmap_array_LEN;
extern const uint8_t* lama_bitmap_array[7];



#endif /* LAMA_H_ */