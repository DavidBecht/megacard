/*
 * display_draw.h
 *
 * Created: 19.12.2025 13:52:32
 *  Author: david
 */ 


#ifndef DISPLAY_DRAW_H_
#define DISPLAY_DRAW_H_

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdbool.h>

//#define DISPLAY_DRAW_SELFTEST

/**
 * @brief Initialisiert das Zeichenmodul und definiert ein Zeichenfenster.
 *
 * Alle Koordinaten (x, y), die in den Zeichenfunktionen verwendet werden,
 * sind IMMER Pixelkoordinaten relativ zu diesem Fenster.
 *
 * @param display_width   Breite des Zeichenbereichs in Pixel.
 * @param display_height  H�he des Zeichenbereichs in Pixel.
 * @param display_x_pos   X-Pixeloffset des Fensters auf dem physischen Display.
 * @param display_y_pos   Y-Pixeloffset des Fensters auf dem physischen Display.
 */
void display_draw_init(uint8_t display_width, uint8_t display_height,
                       uint8_t display_x_pos, uint8_t display_y_pos);


/**
 * @brief L�scht den gesamten Zeichenbereich (alle Pixel).
 *
 * Betrifft ausschlie�lich Pixel im zuvor definierten Zeichenfenster.
 */
void display_draw_clear();


/**
 * @brief Setzt ein einzelnes Pixel.
 *
 * @param x X-Pixelkoordinate relativ zum Zeichenfenster.
 * @param y Y-Pixelkoordinate relativ zum Zeichenfenster.
 */
void display_draw_pixel(uint8_t x, uint8_t y);


/**
 * @brief L�scht ein einzelnes Pixel.
 *
 * @param x X-Pixelkoordinate relativ zum Zeichenfenster.
 * @param y Y-Pixelkoordinate relativ zum Zeichenfenster.
 */
void display_clear_pixel(uint8_t x, uint8_t y);


/**
 * @brief Zeichnet bis zu 8 vertikale Pixel an einer X-Position.
 *
 * x und y sind Pixelkoordinaten. Intern wird y auf die entsprechende
 * Display-Page abgebildet (y bestimmt die 8-Pixel-Gruppe).
 *
 * Jedes Bit im Parameter 'byte' entspricht einem Pixel:
 * Bit 0 = Pixel bei y
 * Bit 7 = Pixel bei y+7
 *
 * @param x    X-Pixelkoordinate relativ zum Zeichenfenster.
 * @param y    Y-Pixelkoordinate (oberstes Pixel des Bytes).
 * @param byte Bitmaske der zu zeichnenden Pixel.
 */
void display_draw_byte(uint8_t x, uint8_t y, uint8_t byte);


/**
 * @brief L�scht bis zu 8 vertikale Pixel an einer X-Position.
 *
 * @param x    X-Pixelkoordinate relativ zum Zeichenfenster.
 * @param y    Y-Pixelkoordinate (oberstes Pixel des Bytes).
 * @param byte Bitmaske der zu l�schenden Pixel.
 */
void display_clear_byte(uint8_t x, uint8_t y, uint8_t byte);


/**
 * @brief Zeichnet eine Linie zwischen zwei Pixelpunkten.
 *
 * Verwendet den Bresenham-Algorithmus.
 *
 * @param x1 Start-X (Pixel)
 * @param y1 Start-Y (Pixel)
 * @param x2 End-X (Pixel)
 * @param y2 End-Y (Pixel)
 */
void display_draw_line(uint8_t x1, uint8_t y1,
                       uint8_t x2, uint8_t y2);


/**
 * @brief L�scht eine Linie zwischen zwei Pixelpunkten.
 *
 * @param x1 Start-X (Pixel)
 * @param y1 Start-Y (Pixel)
 * @param x2 End-X (Pixel)
 * @param y2 End-Y (Pixel)
 */
void display_clear_line(uint8_t x1, uint8_t y1,
                        uint8_t x2, uint8_t y2);


/**
 * @brief Zeichnet eine Linie mit definierter Schrittweite.
 *
 * Alle Koordinaten sind Pixelkoordinaten.
 * Bei step > 1 entsteht eine gestrichelte / punktierte Linie.
 *
 * @param x1   Start-X (Pixel)
 * @param y1   Start-Y (Pixel)
 * @param x2   End-X (Pixel)
 * @param y2   End-Y (Pixel)
 * @param step Schrittweite (1 = durchgehend)
 */
void display_draw_line_with_step(uint8_t x1, uint8_t y1,
                                 uint8_t x2, uint8_t y2,
                                 uint8_t step);


/**
 * @brief L�scht eine Linie mit definierter Schrittweite.
 *
 * @param x1   Start-X (Pixel)
 * @param y1   Start-Y (Pixel)
 * @param x2   End-X (Pixel)
 * @param y2   End-Y (Pixel)
 * @param step Schrittweite
 */
void display_clear_line_with_step(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t step);


/**
 * @brief Zeichnet ein Rechteck.
 *
 * x und y sind Pixelkoordinaten der linken oberen Ecke.
 *
 * @param x      Linke obere X-Pixelposition.
 * @param y      Linke obere Y-Pixelposition.
 * @param width  Breite in Pixel.
 * @param height H�he in Pixel.
 * @param filled true = gef�llt, false = nur Rahmen.
 */
void display_draw_rect(uint8_t x, uint8_t y, uint8_t width, uint8_t height, bool filled);


/**
 * @brief L�scht ein Rechteck.
 *
 * @param x      Linke obere X-Pixelposition.
 * @param y      Linke obere Y-Pixelposition.
 * @param width  Breite in Pixel.
 * @param height H�he in Pixel.
 * @param filled true = gesamte Fl�che l�schen, false = nur Rahmen.
 */
void display_clear_rect(uint8_t x, uint8_t y, uint8_t width, uint8_t height, bool filled);

/**
 * @brief Zeichnet ein generisches Bitmap beliebiger H�he.
 *
 * x und y sind Pixelkoordinaten der linken oberen Ecke.
 * Die Bitmap wird spaltenweise �bergeben.
 *
 * H�he = bytes_per_column * 8 Pixel.
 *
 * @param x                Start-X in Pixel.
 * @param y                Start-Y in Pixel.
 * @param bitmap           Zeiger auf Bitmap-Daten.
 * @param width			   Breite vom Bild in Pixel.
 * @param height		   H�he des Bildes in Pixel.
 * @param horizontal	   Ist das Bitmap horizontal oder vertikal abgelegt (vertikal ist schneller).
 */
void display_draw_bitmap(uint8_t x, uint8_t y, const void *bitmap, uint8_t width,
                         uint8_t height, bool horizontal);

/**
 * @brief Zeichnet ein generisches Bitmap beliebiger H�he transparent.
 *
 * x und y sind Pixelkoordinaten der linken oberen Ecke.
 * Die Bitmap wird spaltenweise �bergeben.
 *
 * H�he = bytes_per_column * 8 Pixel.
 *
 * @param x                Start-X in Pixel.
 * @param y                Start-Y in Pixel.
 * @param bitmap           Zeiger auf Bitmap-Daten.
 * @param width			   Breite vom Bild in Pixel.
 * @param height		   H�he des Bildes in Pixel.
 * @param horizontal	   Ist das Bitmap horizontal oder vertikal abgelegt (vertikal ist schneller).
 */
void display_draw_bitmap_transparent(uint8_t x, uint8_t y, const void *bitmap, uint8_t width, 
									 uint8_t height, bool horizontal);
						
/**
 * @brief L�scht ein generisches Bitmap.
 *
 * @param x                Start-X in Pixel.
 * @param y                Start-Y in Pixel.
 * @param bitmap           Zeiger auf Bitmap-Daten.
 * @param width			   Breite vom Bild in Pixel.
 * @param height		   H�he des Bildes in Pixel.
 * @param horizontal	   Ist das Bitmap horizontal oder vertikal abgelegt (vertikal ist schneller).
 */
void display_clear_bitmap(uint8_t x, uint8_t y, const void *bitmap, uint8_t width,
						  uint8_t height, bool horizontal);



/**
 * @brief Zeichnet ein generisches Bitmap.
 *
 * @param x                Start-X in Pixel.
 * @param y                Start-Y in Pixel.
 * @param bitmap           Zeiger auf Bitmap-Daten im Programmspeicher.
 * @param width			   Breite vom Bild in Pixel.
 * @param height		   H�he des Bildes in Pixel.
 * @param horizontal	   Ist das Bitmap horizontal oder vertikal abgelegt (vertikal ist schneller).
 */
void display_draw_bitmap_P(uint8_t x, uint8_t y, PGM_P bitmap, uint8_t width, 
						   uint8_t height, bool horizontal);

/**
 * @brief Zeichnet ein generisches Bitmap transparent.
 *
 * @param x                Start-X in Pixel.
 * @param y                Start-Y in Pixel.
 * @param bitmap           Zeiger auf Bitmap-Daten im Programmspeicher.
 * @param width			   Breite vom Bild in Pixel.
 * @param height		   H�he des Bildes in Pixel.
 * @param horizontal	   Ist das Bitmap horizontal oder vertikal abgelegt (vertikal ist schneller).
 */						   
void display_draw_bitmap_P(uint8_t x, uint8_t y, PGM_P bitmap, uint8_t width, 
						   uint8_t height, bool horizontal);

/**
 * @brief L�scht ein generisches Bitmap.
 *
 * @param x                Start-X in Pixel.
 * @param y                Start-Y in Pixel.
 * @param bitmap           Zeiger auf Bitmap-Daten im Programmspeicher.
 * @param width			   Breite vom Bild in Pixel.
 * @param height		   H�he des Bildes in Pixel.
 * @param horizontal	   Ist das Bitmap horizontal oder vertikal abgelegt (vertikal ist schneller).
 */
void display_clear_bitmap_P(uint8_t x, uint8_t y, PGM_P bitmap, uint8_t width,
						    uint8_t height, bool horizontal);

/**
 * @brief Schrift-Skalierungsfaktoren im Q8.8-Festkommaformat.
 *
 * Die Werte sind als Faktor * 256 gespeichert.
 * 256 entspricht 1.0x (Originalgr��e).
 *
 * Beispiel:
 *   128  = 0.5  * 256  -> halbe Gr��e
 *   256  = 1.0  * 256  -> normale Gr��e
 *   512  = 2.0  * 256  -> doppelte Gr��e
 *
 * Die Skalierung erfolgt proportional in X- und Y-Richtung.
 */
typedef enum
{
	FONT_SIZE_0_5X  = 128,   ///< 0.5x
	FONT_SIZE_0_75X = 192,   ///< 0.75x
	FONT_SIZE_1X    = 256,   ///< 1.0x (Originalgr��e)
	FONT_SIZE_1_25X = 320,   ///< 1.25x
	FONT_SIZE_1_5X  = 384,   ///< 1.5x
	FONT_SIZE_2X    = 512,   ///< 2.0x
	FONT_SIZE_3X    = 768,   ///< 3.0x
	FONT_SIZE_4X    = 1024   ///< 4.0x
} FontSize_t;


/**
 * @brief Zeichnet ein einzelnes ASCII-Zeichen.
 *
 * Das Zeichen wird aus dem aktuell geladenen Font (FontData.h) gelesen
 * und mit dem angegebenen Skalierungsfaktor vergr��ert oder verkleinert.
 *
 * @param x        Linke obere X-Pixelposition relativ zum Zeichenfenster.
 * @param y        Linke obere Y-Pixelposition relativ zum Zeichenfenster.
 * @param c        ASCII-Zeichen.
 * @param size     Skalierungsfaktor (FontSize_t, Q8.8).
 * @param clear_bg true  = Hintergrundbereich des Zeichens vorher l�schen,
 *                 false = nur gesetzte Pixel zeichnen (�berlagerung m�glich).
 */
void display_draw_char(uint8_t x, uint8_t y, char c, FontSize_t size, bool clear_bg);


/**
 * @brief Zeichnet einen nullterminierten String.
 *
 * Der String wird Zeichen f�r Zeichen gezeichnet, bis '\0' erreicht wird.
 * Zwischen den Zeichen wird das im Font definierte Spacing ber�cksichtigt
 * (ebenfalls skaliert).
 *
 * @param x     Start-X-Pixelposition relativ zum Zeichenfenster.
 * @param y     Start-Y-Pixelposition relativ zum Zeichenfenster.
 * @param s     Zeiger auf nullterminierten String im RAM.
 * @param size  Skalierungsfaktor (FontSize_t).
 */
void display_draw_string(uint8_t x, uint8_t y, const char* s, FontSize_t size);

/**
 * @brief Zeichnet einen nullterminierten String.
 *
 * Der String wird Zeichen f�r Zeichen gezeichnet, bis '\0' erreicht wird.
 * Zwischen den Zeichen wird das im Font definierte Spacing ber�cksichtigt
 * (ebenfalls skaliert).
 *
 * @param x     Start-X-Pixelposition relativ zum Zeichenfenster.
 * @param y     Start-Y-Pixelposition relativ zum Zeichenfenster.
 * @param s     Zeiger auf nullterminierten String im Programmspeicher.
 * @param size  Skalierungsfaktor (FontSize_t).
 */
void display_draw_string_P(uint8_t x, uint8_t y, PGM_P s, FontSize_t size);

#ifdef DISPLAY_DRAW_SELFTEST
#include "animations/lama.h"
void display_draw_selftest_loop();
#endif

#endif /* DISPLAY_DRAW_H_ */