/*-------------------------------------------------------------------------*\
| Datei:        main.c
| Version:      1.0
| Projekt:      Einfuehrung in das Programmieren des Atmega16
| Beschreibung: Grundgeruest fuer die Anzeigebibliothek
| Schaltung:    MEGACARD V5.5
| Autor:
| Erstellung: David Bechtold
|
| Aenderung:
\*-------------------------------------------------------------------------*/
#include <avr/io.h>
#include <util/delay.h>
#include <stdbool.h>
#include "display/display_draw.h"
#include "display/display.h"

int main (void)
{
	// F�r den Selbsttest im Header <display_draw.h> 
	// folgendes define  <//#define DISPLAY_DRAW_SELFTEST>
	// deklarieren und nachfolgende Funktion aufrufen. 
	// Mit Taster S0 die Tests 1-8 durchschalten.
	//display_draw_selftest_loop();
	
	uint8_t display_width = 64;
	uint8_t display_height = 40;
	uint8_t display_x_pos = 32;
	uint8_t display_y_pos = 12;
	display_draw_init(display_width, display_height, display_x_pos, display_y_pos);
	display_draw_rect(0, 0, display_width, display_height, false);
	display_draw_line(0, 0, display_width, display_height);
	display_draw_line(0, display_height, display_width, 0);
	display_draw_string_P(display_width / 2 - 10, 2, PSTR("HALLO"), FONT_SIZE_0_5X);
	
	
	while (1)
	{
		
		
	}

	return 0;
}
